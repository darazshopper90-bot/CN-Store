# Daraz Shopper – GitHub Pages setup

## 1. Repo eka hadanna
1. github.com → **New repository** (e.g. `daraz-shopper`), **Public**.
2. Me folder eke files tika upload karanna: `index.html`, `products.json`, `.nojekyll`.

## 2. Website eka on karanna
Repo → **Settings → Pages** → Source: **Deploy from a branch** → Branch: `main` / `(root)` → Save.
Minute 1–2 kin link eka ready: `https://<username>.github.io/daraz-shopper/`

## 3. Admin token ekak hadanna (ape "password" eka)
1. GitHub → Settings → Developer settings → **Personal access tokens → Fine-grained tokens → Generate new token**.
2. Repository access: **Only select repositories** → ape repo eka.
3. Permissions → Repository permissions → **Contents: Read and write**.
4. Token eka copy karanna (eka kawuruta hari denna epa).

## 4. Products add karanna
1. Website eke yata footer eke **🔒 Admin** click karanna.
2. Repo (`username/daraz-shopper`) saha token eka dinna (eka me browser ekata witharak save wenawa).
3. **+ Add product** → title, description, price, affiliate link, category, photos, badges → Save.
4. Save karama GitHub ekata auto commit wenawa. Visitors ta aluth product penna **1–2 minutes** yanawa.

Notes: photos auto-shrink wenawa (900px). Token ekak web page ekata hard-code karanna epa.
